//
//  DBManager.swift
//  SQLITE_Demo_Swift
//
//  Created by Anil on 29/12/19..
//  Copyright © 2019 Anil. All rights reserved
//

import UIKit

class DBManager: NSObject {

    static let shared: DBManager = DBManager()
    var database : FMDatabase!
    
    
    // MARK: Create Database File Path
    func ensureDatabaseFile() {
        let strPath : NSString = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]  as NSString
        
        let dbFilepath = strPath.appendingPathComponent("/SQLITE_DEMO.sqlite")
        
        let filemanager = FileManager.default
        
        if !filemanager.fileExists(atPath: dbFilepath) {
            let fileforCopy = Bundle.main.path(forResource: "SQLITE_DEMO", ofType: "sqlite")
            
            do
            {
                try filemanager.copyItem(atPath: fileforCopy!, toPath: dbFilepath)
            }
            catch {
                
            }
        }
        
        database = FMDatabase(path: dbFilepath)
        
        print("Database Filepath Delegate : \(dbFilepath)")
        
        database.open()
        dbUpgrade()
    }
    
    // MARK: Database Column Alter
    func dbUpgrade(){
        let arrAlterTableQueries = NSMutableArray()
        
        arrAlterTableQueries.add(String(format: "Alter table %@ Add column StudentId text", globalConstant.kTblNotification))
        arrAlterTableQueries.add(String(format: "Alter table %@ Add column StudentProfile text", globalConstant.kTblNotification))
        
        for i in 0..<arrAlterTableQueries.count {
            do
            {
                let strgetQuery: NSString = arrAlterTableQueries.object(at: i) as! NSString
                let strtblName = strgetQuery.components(separatedBy: " ")[2]
                let strColumnName = strgetQuery.components(separatedBy: " ")[5]
                let arrPragmaTables = NSMutableArray()
                let resultSet = try database.executeQuery("PRAGMA table_info('\(strtblName)')", values: nil)
                while resultSet.next() {
                    arrPragmaTables.add(resultSet.string(forColumn: "name") as Any)
                }
                
                if (!arrPragmaTables.contains(strColumnName)) {
                    try database.executeUpdate(strgetQuery as String, values: nil)
                }
            }
            catch {
                print(error.localizedDescription)
            }
            
        }
    }
    
    // MARK: Insert Data In Local Database
    func insertNotificationData(arrData : NSMutableArray) -> Bool {
        var isAdded = Bool()
        
        var model = NotificationModel()
        
        let arrId = NSMutableArray()
        let arrDb : NSMutableArray = getAllNotification()
        
        for i in 0..<arrDb.count {
            let model : NotificationModel = arrDb.object(at: i) as! NotificationModel
            arrId.add(model.NotificationId)
        }
        
        for i in 0..<arrData.count {
            model = arrData.object(at: i) as! NotificationModel
            
            if arrId.contains(model.NotificationId) {
                //TODO: Update Query Before Alter Table
                let updateQuery = String(format: "update %@ set Notification = ?, Sender = ?, ClassName = ?, StudentProfile = ? where NotificationId = ?", globalConstant.kTblNotification)

                isAdded = database.executeUpdate(updateQuery, withArgumentsIn: [model.Notification, model.Sender, model.ClassName, model.StudentProfile,model.NotificationId])
                
                //TODO: Update Query After Alter Table
//                let updateQuery = String(format: "update %@ set Notification = ?, Sender = ?, ClassName = ? where NotificationId = ? AND StudentId = ?", globalConstant.kTblNotification)
//
//                isAdded = database.executeUpdate(updateQuery, withArgumentsIn: [model.Notification, model.Sender, model.ClassName, model.NotificationId, model.StudentId])
            }
            else {
                //TODO: Insert Query Before Alter Table
                let insertQuery = String(format: "insert into %@(NotificationId, Notification, Sender, ClassName, StudentProfile) values(?, ?, ?, ?, ?)", globalConstant.kTblNotification)

                isAdded = database.executeUpdate(insertQuery, withArgumentsIn: [model.NotificationId, model.Notification, model.Sender, model.ClassName, model.StudentProfile])
                
                //TODO: Insert Query After Alter Table
//                let insertQuery = String(format: "insert into %@(NotificationId, Notification, Sender, ClassName, StudentId) values(?, ?, ?, ?, ?)", globalConstant.kTblNotification)
//
//                isAdded = database.executeUpdate(insertQuery, withArgumentsIn: [model.NotificationId, model.Notification, model.Sender, model.ClassName, model.StudentId])
            }
    
        }
        
        return isAdded
    }
    
    // MARK: Get All Notification From Database
    func getAllNotification() -> NSMutableArray {
        let arrResult = NSMutableArray()
        
        //TODO: Select Query Before Alter Table
        let selectQuery = String(format: "Select * from %@", globalConstant.kTblNotification)
        
        //TODO: Select Query After Alter Table
//        let strStudentId : NSString = "123"
//        let selectQuery = String(format: "Select * from %@ where StudentId = ?", globalConstant.kTblNotification)
        
        do {
            //TODO: Select Query Before Alter Table
            let result = try database.executeQuery(selectQuery, values: [])
            
            //TODO: Select Query After Alter Table
//            let result = try database.executeQuery(selectQuery, values: [strStudentId])
            
            var model = NotificationModel()
            
            while result.next() {
                model = NotificationModel()
                
                model.NotificationId = Int(result.int(forColumn: "NotificationId")) as NSNumber
                model.Notification = result.string(forColumn: "Notification")! as NSString
                model.Sender = result.string(forColumn: "Sender")! as NSString
                model.ClassName = result.string(forColumn: "ClassName")! as NSString
                
                //TODO: get Data After Alter Table
                if let value = result.string(forColumn: "StudentId") {
                    model.StudentId = value as NSString
                }
                
                model.StudentProfile = result.string(forColumn: "StudentProfile")! as NSString
                
                arrResult.add(model)
            }
            return arrResult
        }
        catch {
            return arrResult
        }
        
    }
    
    // MARK: Delete Notification
//    func deleteNotification(strStudentId : NSString, strNotificationId : NSString) -> Bool {
//        var isDeleted = Bool()
//
//        let deleteQuery = String(format: "DELETE FROM %@ WHERE StudentId = ? AND NotificationId = ?", globalConstant.kTblNotification)
//        isDeleted = database.executeUpdate(deleteQuery, withArgumentsIn: [strStudentId, strNotificationId])
//        print("Delete Notification data : \(isDeleted)")
//
//        return isDeleted
//    }
    
    // MARK: Delete Notification Using Tableswipe
    func deleteNotification(strNotificationId : NSString) -> Bool {
        var isDeleted = Bool()
        
        let deleteQuery = String(format: "DELETE FROM %@ WHERE NotificationId = ?", globalConstant.kTblNotification)
        isDeleted = database.executeUpdate(deleteQuery, withArgumentsIn: [strNotificationId])
        print("Delete Notification data : \(isDeleted)")
        
        return isDeleted
    }
}
