//
//  Constant.swift
//  SQLITE_Demo_Swift
//
//  Created by Anil on 29/12/19..
//  Copyright © 2019 Anil. All rights reserved
//

import Foundation

struct globalConstant {
    
    static let kTblNotification = "tblNotification"
}
