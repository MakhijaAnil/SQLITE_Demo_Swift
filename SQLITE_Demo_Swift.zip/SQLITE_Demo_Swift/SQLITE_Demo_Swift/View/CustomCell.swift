//
//  CustomCell.swift
//  SQLITE_Demo_Swift
//
//  Created by Anil on 06/09/18.
//  Copyright © 2019 Anil. All rights reserved
//

import UIKit

class CustomCell: UITableViewCell {

    @IBOutlet weak var lblNotificationId: UILabel!
    @IBOutlet weak var lblNotification: UILabel!
    @IBOutlet weak var lblSender: UILabel!
    @IBOutlet weak var lblClassName: UILabel!
    @IBOutlet weak var imgProfile: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
