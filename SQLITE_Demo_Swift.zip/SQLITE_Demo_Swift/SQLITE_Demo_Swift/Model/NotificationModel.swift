//
//  NotificationModel.swift
//  SQLITE_Demo_Swift
//
//  Created by Anil on 29/12/19..
//  Copyright © 2019 Anil. All rights reserved
//

import UIKit

class NotificationModel: NSObject {

    var NotificationId = NSNumber()
    var Notification = NSString()
    var Sender = NSString()
    var ClassName = NSString()
    
    //TODO: Add Model Object After Alter Table
    var StudentId = NSString()
    var StudentProfile = NSString()
    
}
