//
//  NextViewController.swift
//  SQLITE_Demo_Swift
//
//  Created by Anil on 06/09/18.
//  Copyright © 2019 Anil. All rights reserved
//

import UIKit

class NextViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var arrResult = NSMutableArray()
    
    @IBOutlet weak var tblNotification: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tblNotification.estimatedRowHeight = 30
        tblNotification.rowHeight = UITableViewAutomaticDimension
        
        tblNotification.separatorStyle = .none
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        arrResult = DBManager.shared.getAllNotification()
        
        if arrResult.count > 0 {
            tblNotification.reloadData()
        }
        else {
            
        }
    }

    // MARK: Tableview Method
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrResult.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomCell
        
        if arrResult.count > 0 {
            let model : NotificationModel = arrResult.object(at: indexPath.row) as! NotificationModel
            
            cell.lblNotificationId.text = String(format: "%@", model.NotificationId)
            cell.lblNotification.text = model.Notification as String
            cell.lblSender.text = model.Sender as String
            cell.lblClassName.text = model.ClassName as String
            
            let paths               = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
            if let dirPath          = paths.first
            {
                let imageURL = URL(fileURLWithPath: dirPath).appendingPathComponent(model.StudentProfile.lastPathComponent)
                cell.imgProfile.image = UIImage(contentsOfFile: imageURL.path)
                // Do whatever you want with the image
            }
            
            cell.selectionStyle = .none
        }
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 128
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let edit = UITableViewRowAction(style: UITableViewRowActionStyle.normal, title: "Edit") { (action, index) in
            
            let model : NotificationModel = self.arrResult.object(at: indexPath.row) as! NotificationModel
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "PostNotification"), object: model)
            self.navigationController?.popViewController(animated: true)
            
        }
        
        let remove = UITableViewRowAction(style: UITableViewRowActionStyle.destructive, title: "Delete") { (action, index) in
            
            let model : NotificationModel = self.arrResult.object(at: indexPath.row) as! NotificationModel
            
            let isAdded : Bool = DBManager.shared.deleteNotification(strNotificationId: String(format: "%@", model.NotificationId) as NSString)
            
            self.arrResult.removeObject(at: indexPath.row)
            self.tblNotification.deleteRows(at: [indexPath], with: UITableViewRowAnimation.automatic)
            print("Data Deleted at Row : \(indexPath.row)")
            print("\(isAdded)")
            
        }
        
        
        return [edit, remove]
        
    }
    
    //    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
    //        return UITableViewAutomaticDimension
    //    }

}
