//
//  ViewController.swift
//  SQLITE_Demo_Swift
//
//  Created by Anil on 29/12/19..
//  Copyright © 2019 Anil. All rights reserved
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var txtnotificationid: UITextField!
    @IBOutlet weak var txtNotification: UITextField!
    @IBOutlet weak var txtSender: UITextField!
    @IBOutlet weak var txtClassName: UITextField!
    @IBOutlet weak var imgProfile: UIImageView!
    
    var imagePickerControl = UIImagePickerController()
    var strImageProfile = NSString()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.notify(notify:)), name: NSNotification.Name(rawValue: "PostNotification"), object: nil)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @objc func notify(notify : NSNotification) {
        if notify.name.rawValue == "PostNotification"{
            let model : NotificationModel = notify.object as! NotificationModel
            
            txtnotificationid.text = String(format: "%@", model.NotificationId)
            txtNotification.text = String(format: "%@", model.Notification)
            txtSender.text = String(format: "%@", model.Sender)
            txtClassName.text = String(format: "%@", model.ClassName)
            let paths               = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
            if let dirPath          = paths.first
            {
                let imageURL = URL(fileURLWithPath: dirPath).appendingPathComponent(model.StudentProfile.lastPathComponent)
                imgProfile.image = UIImage(contentsOfFile: imageURL.path)
                // Do whatever you want with the image
            }
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnSendNotification_Clicked(_ sender: Any) {
        
        if txtSender.text?.isEmpty ?? true && txtClassName.text?.isEmpty ?? true && txtNotification.text?.isEmpty ?? true && txtnotificationid.text?.isEmpty ?? true {
            
            let alert = UIAlertController(title: "Message", message: "textField is empty.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
            self.present(alert, animated: true)

            print("textField is empty")
        } else {
            print("textField has some text")
            let model = NotificationModel()
            model.NotificationId = Int(txtnotificationid.text!)! as NSNumber
            model.Notification = txtNotification.text! as NSString
            model.Sender = txtSender.text! as NSString
            model.ClassName = txtClassName.text! as NSString
            model.StudentProfile = strImageProfile
            
            let arrResult = NSMutableArray()
            
            arrResult.add(model)
            
            let isAdded : Bool = DBManager.shared.insertNotificationData(arrData: arrResult)
            
            if isAdded {
                let alert = UIAlertController(title: "Message", message: "Notification Data Added...", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
                self.present(alert, animated: true)
                print("Notification Data Added...")
            }
        }
        
    }
    
    @IBAction func btnDeleteNotification(_ sender: Any) {
        
//        let strStudentId : NSString = txtnotificationid.text! as NSString
        let strNotificationId : NSString = txtnotificationid.text! as NSString
        
//        let isDeleted : Bool = DBManager.shared.deleteNotification(strStudentId: strStudentId, strNotificationId: strNotificationId)

        let isDeleted : Bool = DBManager.shared.deleteNotification(strNotificationId: strNotificationId)
        if isDeleted {
            print("Notification Data Deleted...")
        }
    }
    
    @IBAction func btnViewData_Clicked(_ sender: Any) {
        let nextview = self.storyboard?.instantiateViewController(withIdentifier: "nextview") as! NextViewController
        
        self.navigationController?.pushViewController(nextview, animated: true)
    }
    
    @IBAction func btnImageTap_Clicked(_ sender: Any) {
        
        let imageSource = UIAlertController(title: "ImagePicker Demo", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let cameraAlert = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default) { (_) in
            
        }
        
        let galleryAlert = UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default) { (_) in
            self.selectGallery()
        }
        
        imageSource.addAction(cameraAlert)
        imageSource.addAction(galleryAlert)
        
        present(imageSource, animated: true, completion: nil)
    }
    
    func selectGallery(){
        
        imagePickerControl = UIImagePickerController()
        imagePickerControl.sourceType = .photoLibrary
        imagePickerControl.delegate = self
        imagePickerControl.allowsEditing = false
        present(imagePickerControl, animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage{
            
            self.imgProfile.image = pickedImage
            
        }
        
        if let imgUrl = info[UIImagePickerControllerImageURL] as? URL{
            print(imgUrl)
            let imgName = imgUrl.lastPathComponent
            let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first
            let localPath = documentDirectory?.appending("/\(imgName)")
            
            let image = info[UIImagePickerControllerOriginalImage] as! UIImage
            let data = UIImagePNGRepresentation(image)! as NSData
            data.write(toFile: localPath!, atomically: true)
            
            strImageProfile = String(format: "%@", localPath!) as NSString
        }
        
        
        picker.dismiss(animated: true, completion: nil)
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        picker.dismiss(animated: true, completion: nil)
        
    }
}

